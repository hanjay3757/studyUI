const Home:React.FC=()=>{
    return(
        <div className="container py-4 text-center">
            <h1>Home</h1>
        </div>
    )
}
export default Home;