const express = require('express')
const router =express.Router();
const loginController = require('../controllers/loginController')
// '/api/auth/login'
router.post('/login', loginController.login)
router.post('/logout', loginController.logout)
router.post('/refresh', loginController.refreshVerify)

module.exports = router;