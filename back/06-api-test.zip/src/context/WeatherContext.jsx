import { createContext } from "react";

const WeatherContext = createContext(null);
export default WeatherContext;